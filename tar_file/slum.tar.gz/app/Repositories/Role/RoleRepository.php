<?php

namespace App\Repositories\Role;

use App\Role;

interface RoleRepository
{
    
}
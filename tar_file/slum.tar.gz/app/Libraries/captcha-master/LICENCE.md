Copyright (c) 2015 Muharrem ERİN (me@mewebstudio.com)

http://www.opensource.org/licenses/mit-license.php The MIT License

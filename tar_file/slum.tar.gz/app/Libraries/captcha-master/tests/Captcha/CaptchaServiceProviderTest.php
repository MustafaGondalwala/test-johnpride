<?php

namespace Mews\Tests\Captcha;

use Mockery;

class CaptchaServiceProviderTest extends \PHPUnit_Framework_TestCase
{
    public function testRegister()
    {
        $this->assertTrue(true);
    }
}

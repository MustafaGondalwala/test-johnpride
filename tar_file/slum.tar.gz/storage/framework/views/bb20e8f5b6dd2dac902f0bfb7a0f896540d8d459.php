<title><?php echo e((isset($meta_title))?$meta_title:''); ?></title>

<meta name="description" content="<?php echo e((isset($meta_description))?$meta_description:''); ?>"/>
<meta name="keywords" content="<?php echo e((isset($meta_keyword))?$meta_keyword:''); ?>"/>


<link rel="profile" href="http://gmpg.org/xfn/11">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta property="og:site_name" content="SlumberJill"/>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/style.css')); ?>" />
<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet" /> 
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,700" rel="stylesheet" />

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo (isset($meta_title))?$meta_title:'SlumberJill'?></title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index, follow"/>
<meta name="robots" content="noodp, noydir"/>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="fullwidth innerpage">
 	<div class="container">
		<?php echo $__env->make('users.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<div class="rightcontent">
			<div class="heading2">Update Profile</div>
			<div class="c-heading formbox">
			<ul>
			   
			  <li><span>First Name<cite>*</cite></span> <span>
				<input type="text" name="first_name" value="" id="first_name" class="inputfild" >
				</span>
				</li>
			  <li><span>Last Name<cite>*</cite></span> <span>
				<input type="text" name="last_name" value="" id="last_name" class="inputfild" >
				</span>
				</li>

			  <li><span>Business Name</span> <span>
				<input type="text" name="company" value="" id="company" class="inputfild" >
				</span>
				</li>
			  <li><span>Telephone<cite>*</cite></span> <span>
				<input type="text" name="phone" value="" id="phone" class="inputfild" >
				</span></li>
			  <li class="fullwidth"><span>Address (House No, Building, Street, Area) <cite>*</cite></span> <span>
				<input name="address1" id="address1" type="text" class="inputfild" value="India Internet"> 
				</span></li>
			  <li><span>City<cite>*</cite></span> <span>
				<input name="city" id="city" type="text" class="inputfild" value="Delhi">
				</span></li>
			  <li><span>State / Province<cite>*</cite></span> <span>
				<input name="state" id="state" type="text" class="inputfild" value="Delhi">
				</span></li>
			  <li><span>Postal Code<cite>*</cite></span> <span>
				<input name="post_code" id="post_code" type="text" class="inputfild" value="201301" />
				</span></li>
			  <li><span>Country<cite>*</cite></span> <span>
				<select name="country" id="country" class="inputfild">
					<option value="1">Afghanistan</option>
					<option value="2">Albania</option>
					<option value="3">Algeria</option>
					<option value="4">American Samoa</option>
					<option value="5">Andorra</option>
					<option value="6">Angola</option>

				  </select>
				</span> </li>
				
				<li><button class="savebtn">Save</button></li>

			</ul>
		  </div>
		</div>
	</div>
</section>
 
<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
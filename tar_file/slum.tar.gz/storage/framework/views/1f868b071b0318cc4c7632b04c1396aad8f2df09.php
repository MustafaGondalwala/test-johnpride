<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo (isset($meta_title))?$meta_title:'SlumberJill'?></title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="robots" content="index, follow"/>
    <meta name="robots" content="noodp, noydir"/>

    <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

    <?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php
    $name = trim($user->first_name.' '.$user->last_name);
    $phone = $user->phone;
    $email = $user->email;

    $addressArr = CustomHelper::formatAuthUserAddress($user);

//pr($errors->count());

    $pwdBoxDisp = '';
    $changePwdLinkDisp = '';

    if($errors->count() > 0){
        $pwdBoxDisp = 'display:block;';
        $changePwdLinkDisp = 'display:none;';
    }

    ?>

    <section class="fullwidth innerpage">
      <div class="container">
          <?php echo $__env->make('users.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
          <div class="rightcontent">
              <div class="heading2">Profile </div>

              <?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <div class="accountinner">  <a class="edit-link" href="<?php echo e(url('users/update')); ?>"><i class="editicon"></i></a>
                <p><span>NAME:</span> <small> <?php echo e($name); ?></small> </p>

                <p>
                    <span>BILLING ADDRESS:</span>
                    <?php
                    if(!empty($addressArr) && count($addressArr) > 0){
                        ?>
                        <small><?php echo implode(', ', $addressArr); ?></small>
                        <?php
                    }
                    ?>
                </p>

                <p><span>DELIVERY  ADDRESS</span> <small>  Same as billing address.</small></p>
                <p><span>PHONE NUMBER:</span>  <small><?php echo e($phone); ?></small></p>
                <p><span>EMAIL:</span>  <small><?php echo e($email); ?></small></p>
                
                <p class="change-pwd-link " style="<?php echo e($changePwdLinkDisp); ?>"><span>PASSWORD:</span>  <small><a href="javascript:void(0)" class="showPwdBox" >Change password</a></small></p>
                
                <div class="change-pwd" style="<?php echo e($pwdBoxDisp); ?>" >

                    <form name="changePassForm" method="POST" id="changePWD">
                        <?php echo e(csrf_field()); ?>


                        <p class="success"></p>
                        <p class="error"></p>

                        <p>
                            <span>Current Password:</span>
                            <small><input type="password" name="current_password" class="inputfild" style="max-width:200px"></small>
                            <?php echo $__env->make('snippets.front.errors_first', ['param' => 'current_password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </p>

                        <p>
                            <span>New Password:</span>
                            <small><input type="password" name="new_password" class="inputfild" style="max-width:200px"></small>
                            <?php echo $__env->make('snippets.front.errors_first', ['param' => 'new_password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </p>
                        <p>
                            <span>Confirm Password:</span>
                            <small><input type="password" name="confirm_password" class="inputfild" style="max-width:200px"></small>
                            <?php echo $__env->make('snippets.front.errors_first', ['param' => 'confirm_password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </p>

                        <p>
                            <span> </span>
                            <small>
                                <button type="submit" id="change-pwd-btn" name="savePwd" class="savebtn">Save</button>
                                <button type="button" class="btn btn-default hidePwdBox">Cancel</button>
                            </small>
                        </p>

                    </form> 
                </div>       
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
    $(".hidePwdBox").click(function(){
        $(".change-pwd").hide();
        $(".change-pwd-link ").show();
    });
    $(".showPwdBox").click(function(){
        $('.change-pwd').show();
        $('.change-pwd-link').hide();
    });
</script>

</body>
</html>
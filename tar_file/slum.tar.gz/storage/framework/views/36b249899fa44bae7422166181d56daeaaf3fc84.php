<?php $__env->startComponent('admin.layouts.main'); ?>

    <?php $__env->slot('title'); ?>
        Admin - <?php echo e($title); ?> - <?php echo e(config('app.name')); ?>

    <?php $__env->endSlot(); ?>
 
    <div class="row">

        <div class="col-md-12">

            <h2><?php echo e($heading); ?></h2>
            <div class="bgcolor">

            <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(session('errMsg')): ?>
            <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('errMsg')); ?>

            </div>
            <?php endif; ?>

            <?php
            //prd($shippingzones);
            $shippingzone_id = (isset($shippingzones['id']))?$shippingzones['id']:0;
            $name = (isset($shippingzones['name']))?$shippingzones['name']:'';
            $status = (isset($shippingzones['status']))?$shippingzones['status']:1;

            if(is_numeric($shippingzone_id) && $shippingzone_id > 0){
                $action_url = url('admin/shippingzones/edit', $shippingzone_id);
            }
            else{
                $action_url = url('admin/shippingzones/add');
            }

            
            ?>

            <form method="POST" action="<?php echo e($action_url); ?>" accept-charset="UTF-8" enctype="multipart/form-data" role="form">
                <?php echo e(csrf_field()); ?>

                <?php
            //echo 'user_id='.$user_id; die;

            ?>

           

                <div class="form-group col-md-4<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="control-label">Name:</label>

                    <input type="text" id="name" class="form-control" name="name" value="<?php echo e(old('name', $name)); ?>" maxlength="255" />

                    <?php echo $__env->make('snippets.errors_first', ['param' => 'name'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <?php
                $sel_status = old('status', $status);
                ?>
                <div class="form-group col-md-4<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">

                    <label for="type" class="control-label required">Status:</label>
                    <br>
                    <input type="radio" name="status" value="1" <?php echo e(($sel_status == 1)?'checked':''); ?>>&nbsp;Active
                    &nbsp;
                    <input type="radio" name="status" value="0" <?php echo e(($sel_status == 0)?'checked':''); ?>>&nbsp;Inactive

                    <?php echo $__env->make('snippets.errors_first', ['param' => 'status'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
				
				<div class="clearfix"></div>
                <div class="form-group col-md-4">

                <input type="hidden" name="shippingzone_id" value="<?php echo e($shippingzone_id); ?>">
                <br>

                    <button class="btn btn-success"><i class="fa fa-save"></i> Save</button>

                    <?php
                    if($shippingzone_id > 0){
                        ?>
                        <a href="<?php echo e(url('admin/shippingzones')); ?>" class="btn btn-lg btn-primary" title="Cancel">Cancel</a>
                        <?php
                    }
                    ?>
                    
                </div>
				<div class="clearfix"></div>
                <div class="form-group col-md-12">
                    <div class="row">
                        <?php
                        $zonecityId = array();

                        if(isset($ShippingZonesCities) && count($ShippingZonesCities) > 0){
                            foreach($ShippingZonesCities as $zonecity){
                                $zonecityId[] = $zonecity->city_id;
                            }
                        }

                        if(count($cities) > 0){
                            $count_city = 0;
                            ?>

                            <div class="col-md-4">
                                <ul class="Shipping-ul">
                                    <?php
                                    foreach($cities as $city){
                                        $checked = '';
                                        if(in_array($city->id, $zonecityId)){
                                            $checked = 'checked';
                                        }
                                        ?>
                                        <li><?php echo e($city->name); ?> : <input type="checkbox" name="city_id[]" value="<?php echo e($city->id); ?>" <?php echo e($checked); ?>></li>
                                        <?php
                                        $count_city++;

                                        if($count_city > 30){
                                            $count_city = 0;
                                            ?>
                                        </ul>
                                    </div>

                                    <div class="col-md-4">
                                        <ul class="Shipping-ul">
                                            <?php
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
				<div class="clearfix"></div>	
            </form>
        </div>
            
        </div>
    </div>


<?php echo $__env->renderComponent(); ?>
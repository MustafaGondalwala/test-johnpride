<?php $__env->startComponent('admin.layouts.main'); ?>

<?php $__env->slot('title'); ?>
Admin - Manage Banners - <?php echo e(config('app.name')); ?>

<?php $__env->endSlot(); ?>

<?php
$BackUrl = CustomHelper::BackUrl();
?>

<div class="row">

    <div class="col-md-12">

        <h2>Manage Banners
            <a href="<?php echo e(route('admin.banners.add').'?back_url='.$BackUrl); ?>" class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i> New Banner</a>
        </h2>

        <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php
        if(!empty($banners) && count($banners) > 0){
            ?>

            <div class="table-responsive">

                <table class="table table-striped">
                    <tr>
                        <th>Title</th>
                        <th>Sub-title</th>  
                        <th>Page</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    foreach($banners as $banner){
                        ?>
                        
                        <tr>
                            <td><?php echo $banner->title; ?></td>
                            <td><?php echo e($banner->subtitle); ?></td>
                            <td><?php echo e((isset($page_arr[$banner->page]))?$page_arr[$banner->page]:ucwords($banner->page)); ?></td>
                            <td><?php echo e(CustomHelper::getStatusStr($banner->status)); ?></td>

                            <td>
                                <a href="<?php echo e(route('admin.banners.edit', $banner->id.'?back_url='.$BackUrl)); ?>"><i class="fas fa-edit"></i></a>                                    
                                <a href="javascript:void(0)" class="sbmtDelForm"  id="<?php echo e($banner->id); ?>"><i class="fas fa-trash-alt"></i></i></a>
                                
                                <form method="POST" action="<?php echo e(route('admin.banners.delete', $banner->id)); ?>" accept-charset="UTF-8" role="form" onsubmit="return confirm('Do you really want to remove this Banner?');" id="delete-form-<?php echo e($banner->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('POST')); ?>

                                    <input type="hidden" name="banner_id" value="<?php echo $banner->id; ?>">

                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
            </div>
            <?php echo e($banners->appends(request()->query())->links()); ?>

            <?php
        }
        else{
            ?>
            <div class="alert alert-warning">No banners found.</div>
            <?php
        }
        ?>

    </div>

</div>

<?php echo $__env->renderComponent(); ?>


<script type="text/javaScript">
    $('.sbmtDelForm').click(function(){
        var id = $(this).attr('id');
        $("#delete-form-"+id).submit();
    });
</script>
<?php $__env->startComponent('admin.layouts.main'); ?>

    <?php $__env->slot('title'); ?>
        Admin - Shipping Zones - <?php echo e(config('app.name')); ?>

    <?php $__env->endSlot(); ?>

   
	<div class="row">
		<div class="col-md-12">
			<div class="titlehead">
				<h1 class="pull-left">Shipping Zones</h1>
				<a href="<?php echo e(url('admin/shippingzones/add')); ?>" class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i> Add Shipping Zone</a>
			</div>
		</div>
	</div>         
            
    <div class="row">

        <div class="col-md-12">

            <?php if(session('sccMsg')): ?>
            <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('sccMsg')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('errMsg')): ?>
            <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('errMsg')); ?>

            </div>
            <?php endif; ?>


            <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(session('errMsg')): ?>
            <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('errMsg')); ?>

            </div>
            <?php endif; ?>
            
          
            <div class="table-responsive">

            <table class="table table-striped table-bordered table-hover">
                <tr>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php
                if(!empty($ShippingZone_list) && count($ShippingZone_list) > 0){
                    foreach($ShippingZone_list as $sz){
                    ?>
                    <tr>
                        <td><?php echo e($sz->name); ?></td>

                        <td><?php echo e(CustomHelper::getStatusStr($sz->status)); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/shippingzones/edit/'.$sz->id)); ?>" class=""><i class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" class="delete" data-id="<?php echo e($sz->id); ?>"><i class="fas fa-trash-alt"></i></a>

                            
                            <form name="delete_shippingzone" method="post" action="<?php echo e(url('admin/shippingzones/delete/'.$sz->id)); ?>" onsubmit="return confirm('Are you sure to delete this record?')" style="display: inline-block;" id="delete-form-<?php echo e($sz->id); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="POST">
                            </form>

                            <?php
                            ?>
                        </td>
                    </tr>

                    <?php
                }
                ?>

            <?php
            }
            ?>
                
            </table>
            <?php echo e($ShippingZone_list->appends(request()->query())->links()); ?>

            </div>
            <hr />


        </div>

    </div>

<?php echo $__env->renderComponent(); ?>
<script>
    $('.delete').click(function()
    {
        var id = $(this).attr('data-id');
        $("#delete-form-"+id).submit();
    });
</script>
<?php $__env->startComponent('admin.layouts.main'); ?>

    <?php $__env->slot('title'); ?>
        Admin Panel - <?php echo e(config('app.name')); ?>

    <?php $__env->endSlot(); ?>


<!-- weekly_orders -->

    <div class="row">
        <div class="col-md-12">
            <h1>Dashboard</h1>
        </div>
    </div>

    <div class="row"></div>

<?php echo $__env->renderComponent(); ?>
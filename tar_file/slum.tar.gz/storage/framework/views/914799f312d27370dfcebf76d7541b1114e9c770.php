<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password::SlumberJill</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index, follow"/>
<meta name="robots" content="noodp, noydir"/>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php
$referer = (request()->has('referer'))?request()->referer:'';
?>

<section class="logsec">
  <div class="container">
    <div class="logbox">
	  <h1>Forgot password!</h1>
		<div class="loginform">

			<?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form name="forgotForm" method="post">
            	<?php echo e(csrf_field()); ?>


            	<input type="email" name="email" placeholder="Your Email ID" />
            	<?php echo $__env->make('snippets.front.errors_first', ['param' => 'email'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            	<input class="submitbtn" type="submit" value="Submit" />
            </form>

		</div>

		<div class="formbot">
			 <p><a href="<?php echo e(url('account/login?referer='.$referer)); ?>">Login here!</a> </p>
		</div>
	  </div>
  </div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
<?php echo $__env->make('emails.include.email_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <table class="table">
    <tr>
    <td>Hello, <br>Please click on link given below to reset your password.<br><?php echo $reset_link; ?> </td>
    </tr> 
	 
	 <tr>
    <td>Thanks &amp; regards <br>SlumberJill</td>
    </tr>
 </table> 


<?php echo $__env->make('emails.include.email_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="sidebarsec">
	<div class="filtertitle">
      <span class="filtermobile">My Account <small></small></span>      
    </div>
	<div class="navheading">Orders</div>
	<ul class="accountlefsec">
		<li><a href="<?php echo e(url('users/orders')); ?>">Orders History</a></li>
	</ul>
	<div class="navheading">Credits</div>
	<ul class="accountlefsec"> 
		<li><a href="<?php echo e(url('users/wallet')); ?>">Wallet</a></li> 
	</ul>
	<div class="navheading">Account</div>
	<ul class="accountlefsec">
		<li><a href="<?php echo e(url('users/profile')); ?>">Profile</a></li> 
		<li><a href="<?php echo e(url('users/update')); ?>">Update Profile</a></li>
	</ul>
</div>
<!DOCTYPE html>
<html>
<head>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
	
<section class="fullwidth logpage">	
	<div class="container">
		<div class="regform">
			<h2>Verify Account</h2>

			<?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			

			<form name="verifyAccountForm" method="POST" >

				<?php echo e(csrf_field()); ?>


				<ul>

					<li class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

						<label>Email*</label>
						<input type="text" name="email" value="<?php echo e(old('email')); ?>" class="inputfild"/>
						<?php echo $__env->make('snippets.errors_first', ['param' => 'email'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<br>

						<input class="loginbtn" type="submit" value="Verify" />
					</li>
				</ul>
			 
			</form>

		</div> 
	</div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
</body>
</html>
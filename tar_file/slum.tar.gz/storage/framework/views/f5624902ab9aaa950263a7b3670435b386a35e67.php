<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<div style="max-width:800px; margin: 0 auto;">
	<div style="border: 1px solid #ccc;">
<table class="table table-striped" >
	<tr>
		
		<td colspan="2"><img src="<?php echo url('public/images/logo.png'); ?>" alt="SlumberJill" style="width: 250"></td>

		<td colspan="2" valign="middle" style="text-align: right"> <strong style=" font-size: 20px; padding-top:15px; display: inline-block">+91 - 0123 - 1234567</strong></td>
	</tr>
</table>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signup::SlumberJill</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index, follow"/>
<meta name="robots" content="noodp, noydir"/>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php
$referer = (request()->has('referer'))?request()->referer:'';
?>

<section class="logsec">
  <div class="container">
    <div class="logbox">
	  <h1>Login to SlumberJill</h1>
		<div class="logdiv">
		<a class="signfacebook" href="#"><i class="facebooklogin"></i> Sign up with Facebook</a>
		<a class="signgoogle" href="#"><i class="googlelogin"></i> Sign up with Google</a>
		</div>
		<div class="or">OR</div>
		<div class="loginform">

			<!-- <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->

            <?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>            


			<form name="registerForm" method="POST">
				<?php echo e(csrf_field()); ?>


				<input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email ID" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'email'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<input type="password" name="password" placeholder="Choose Password" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<input type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Mobile Number" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'mobile'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<?php
				$oldGender = old('gender');
				?>

				<span>
					<label><input type="radio" name="gender" value="M" <?php echo ($oldGender == 'M')?'checked':'';?> /> Male</label>
					<label><input type="radio" name="gender" value="F" <?php echo ($oldGender == 'F')?'checked':'';?> /> Female</label>
					<?php echo $__env->make('snippets.front.errors_first', ['param' => 'gender'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</span>

				<input class="submitbtn" type="submit" value="Register" />
			</form>

		</div>
		<div class="formbot">
			 <p>Already have an account? <a href="<?php echo e(url('account/login?referer='.$referer)); ?>">Login!</a> </p>
		</div>
	  </div>
  </div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
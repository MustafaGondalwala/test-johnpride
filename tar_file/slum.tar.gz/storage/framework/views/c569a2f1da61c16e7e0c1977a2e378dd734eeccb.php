<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo (isset($meta_title))?$meta_title:'SlumberJill'?></title>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="robots" content="index, follow"/>
	<meta name="robots" content="noodp, noydir"/>

	<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

	<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php
	$first_name = $user->first_name;
	$last_name = $user->last_name;
	$company_name = $user->company_name;
	$phone = $user->phone;
	$address = $user->address;

	$country = $user->country;
	$state = $user->state;
	$city = $user->city;
	$pincode = $user->pincode;
	?>

	<section class="fullwidth innerpage">
		<div class="container">
			<?php echo $__env->make('users.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<div class="rightcontent">
				<div class="heading2">Update Profile</div>
				<div class="c-heading formbox">

					<?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<form name="updateForm" method="POST">
						<?php echo e(csrf_field()); ?>


						<ul>

							<li>
								<span>First Name<cite>*</cite></span>
								<span>
									<input type="text" name="first_name" value="<?php echo e(old('first_name', $first_name)); ?>" class="inputfild" >
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'first_name'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>Last Name<cite>*</cite></span>
								<span>
									<input type="text" name="last_name" value="<?php echo e(old('last_name', $last_name)); ?>" class="inputfild" >
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'last_name'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>Business Name</span>
								<span>
									<input type="text" name="company_name" value="<?php echo e(old('company_name', $company_name)); ?>" class="inputfild" >
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'company_name'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>Telephone<cite>*</cite></span>
								<span>
									<input type="text" name="phone" value="<?php echo e(old('phone', $phone)); ?>" class="inputfild" >
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'phone'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li class="fullwidth">
								<span>Address (House No, Building, Street, Area) <cite>*</cite></span>
								<span>
									<textarea name="address" class="inputfild"><?php echo e(old('address', $address)); ?></textarea>
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'state'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>State / Province<cite>*</cite></span>
								<span>
									<select name="state" class="inputfild">
										<option value="">--Select--</option>

										<?php

										if(!empty($states) && count($states) > 0){
											foreach($states as $st){
												$selected = '';
												if($st->id == $state){
													$selected = 'selected';
												}
												?>
												<option value="<?php echo e($st->id); ?>" <?php echo e($selected); ?> ><?php echo e($st->name); ?></option>
												<?php
											}
										}
										?>
									</select>

									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'state'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>


							<li>
								<span>City<cite>*</cite></span>
								<span>
									<select name="city" class="inputfild">
										<option value="">--Select--</option>
									</select>

									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'city'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>Pincode<cite>*</cite></span>
								<span>
									<input type="text" name="pincode" value="<?php echo e(old('pincode', $pincode)); ?>" class="inputfild" />
									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'pincode'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li>
								<span>Country<cite>*</cite></span>
								<span>
									<select name="country" class="inputfild" >
										<option value="99">India</option>
									</select>

									<?php echo $__env->make('snippets.front.errors_first', ['param' => 'country'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</span>
							</li>

							<li><button class="savebtn">Save</button></li>

						</ul>

					</form>

				</div>
			</div>
		</div>
	</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
	var state_id = '<?php echo e($state); ?>';
	var city_id = '<?php echo e($city); ?>';

	if(state_id && state_id != ""){
		load_cities( state_id, city_id );
	}

	$(document).on("change", "select[name='state']", function () {
		state_id = $( this ).val();
		load_cities( state_id, city_id );
	} );

	function load_cities( state_id, city_id ) {

		_token = '<?php echo e(csrf_token()); ?>';

		$.ajax( {
			url: "<?php echo e(url('common/ajax_load_cities')); ?>",
			type: "POST",
			data: {state_id: state_id, city_id: city_id},
			dataType: "JSON",
			headers: {
				'X-CSRF-TOKEN': _token
			},
			cache: false,
			beforeSend: function () {},
			success: function ( resp ) {
				if ( resp.success ) {
					$("select[name='city']").html( resp.options );
				}
			}
		} );
	}
</script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signup::SlumberJill</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index, follow"/>
<meta name="robots" content="noodp, noydir"/>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="logsec">
  <div class="container">
    <div class="logbox">


    	<?php
	  if($isValidToken){
	  	?>
	  	<h1>Reset password</h1>

		<div class="loginform">

			<!-- <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->

            <?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>            


			<form name="registerForm" method="POST">
				<?php echo e(csrf_field()); ?>


				<input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email ID" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'email'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<input type="password" name="password" placeholder="Enter Password" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<input type="password" name="confirm_password" placeholder="Confirm Password" />
				<?php echo $__env->make('snippets.front.errors_first', ['param' => 'confirm_password'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<input class="submitbtn" type="submit" value="Register" />
			</form>

		</div>
	  	<?php
	  }
	  else{
	  	?>
	  	<h1>Invalid request</h1>

	  	<div class="formbot">
	  		<a href="<?php echo e(url('account/register')); ?>">Create new account</a> | <a href="<?php echo e(url('account/login')); ?>">Login here!</a>
	  	</div>

	  	<?php
	  }
	  ?>
	  
		<div class="formbot">
			 <p>Already have an account? <a href="<?php echo e(url('account/login')); ?>">Login!</a> </p>
		</div>
	  </div>
  </div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
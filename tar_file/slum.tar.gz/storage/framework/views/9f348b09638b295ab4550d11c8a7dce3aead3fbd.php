<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e($cms['title']); ?></title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="index, follow"/>
<meta name="robots" content="noodp, noydir"/>

<?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section>
  <div class="contentArea">
    <div class="rightBar">
      <div class="container-custom">
        <div class="panel panel-default"> 
          <div class="topHeading panel-heading"><span></span><span></span><span></span><?php echo e($cms['title']); ?></div>
          <div class="panel-body">
            <div class="col-md-12">
            <?php echo $cms['content']; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
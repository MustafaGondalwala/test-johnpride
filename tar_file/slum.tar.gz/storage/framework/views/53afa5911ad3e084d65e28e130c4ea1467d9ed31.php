<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo (isset($meta_title))?$meta_title:'SlumberJill'?></title>
	<meta name="description" content=""/>
	<meta name="keywords" content=""/>
	<meta name="robots" content="index, follow"/>
	<meta name="robots" content="noodp, noydir"/> <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

	<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<section class="fullwidth innerpage wishlistsec">
		<div class="container">

			<?php echo $__env->make('snippets.front.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<ul class="listpro wishlisting">

				<?php
				if(!empty($wishlistProducts) && count($wishlistProducts) > 0){

					$storage = Storage::disk('public');

					$img_path = 'products/';

					foreach($wishlistProducts as $product){
						$product_image = (isset($product->defaultImage))?$product->defaultImage:'';
						$reverse_image = (isset($product->reverseImage))?$product->reverseImage:'';

						$price = $product->price;
						$salePrice = $product->sale_price;

						$productPrice = $price;
						if(is_numeric($salePrice) && $salePrice < $price && $salePrice > 0){
							$productPrice = $product->sale_price;
						}
						else{
							$salePrice = $product->price;
						}

						?>
						<li>
							<div class="removelist"><a href="javascript:void(0)" data-pid="<?php echo e($product->id); ?>" class="delWishlistItem"><i class="deleteicon"></i></a> </div>
							<div class="product">

								<div class="flip-inner">
									<img src="http://slumberjill.ii71.com/public/images/blank.png" alt="img">

									<?php
									if(!empty($product_image->image) && $storage->exists($img_path.$product_image->image)){
										?>
										<div class="flip-front">
											<img src="<?php echo e(url('public/storage/'.$img_path.$product_image->image)); ?>" alt="<?php echo e($product->name); ?>" />
										</div>
										<?php
									}

									if(!empty($reverse_image->image) && $storage->exists($img_path.$reverse_image->image)){
										?>
										<div class="flip-back">
											<img src="<?php echo e(url('public/storage/'.$img_path.$reverse_image->image)); ?>" alt="<?php echo e($product->name); ?>" />
										</div>
										<?php
									}
									?>

								</div>
							</div>
							<div class="procont">
								<p><span> <?php echo e($product->name); ?> </span>
								</p>
								<p> <?php echo e($product->name); ?> </p>
								<p><strong>Just</strong><small>&#x20B9;<?php echo e($productPrice); ?></small>
									<?php
									if(is_numeric($salePrice) && $salePrice < $price && $salePrice > 0){
										?>
										<del>&#x20B9;<?php echo e($price); ?></del> 
										<?php
									}
									?>
								</p>
								<p><a class="movetobag" href="<?php echo e(url('products/details/'.$product->slug)); ?>">MOVE TO BAG</a></p>
							</div>
						</li>
						<?php
					}
				}
				else{
					?>					
					<h3>Currently, you do not have any item(s) in your wishlist.</h3>
					<p><a href="<?php echo e(url('products')); ?>">click here to browse our collection.</a></p>		
					<?php
				}
				?>
				

			</ul>
		</div>
	</section>


	<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script type="text/javascript">

		$(".delWishlistItem").on("click", function(){
			var currSel = $(this);

			var conf = confirm("Are you sure you want to delete this Item?");

			if(conf){

				var productId = currSel.data("pid");

				var _token = '<?php echo e(csrf_token()); ?>';

				$.ajax({
					url: "<?php echo e(url('users/delete_from_wishlist')); ?>",
					type: "POST",
					data: {productId:productId},
					dataType:"JSON",
					headers:{'X-CSRF-TOKEN': _token},
					cache: false,
					beforeSend:function(){

					},
					success: function(resp){
						if(resp.success){
							window.location.reload();
						}

					}
				});

			}

		});
	</script>

</body>
</html>
<div style="background:#272727; padding: 15px; text-align: center; color:#fff; width: 100%;">© <?php echo date('Y'); ?> SlumberJill. All rights reserved.</div>
</div>
</div>
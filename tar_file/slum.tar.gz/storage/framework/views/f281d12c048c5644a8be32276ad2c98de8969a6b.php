<?php if($errors->has($param)): ?>
    <p class="help-block" style="color:red;">
        <?php echo e($errors->first($param)); ?>

    </p>
<?php endif; ?>
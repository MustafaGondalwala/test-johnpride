<?php echo $__env->make('emails.include.email_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <table class="table">
    <tr>
    <td>Hello, <br><br> You have successfully registered. <br>Please click on link given below to verify your email address.
		<br><?php echo $verify_link; ?> </td>
    </tr> 
	 
	 <tr>
    <td>Thanks &amp; regards <br>SlumberJill</td>
    </tr>
 </table> 
 
<?php echo $__env->make('emails.include.email_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
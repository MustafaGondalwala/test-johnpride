<?php $__env->startComponent('admin.layouts.main'); ?>

    <?php $__env->slot('title'); ?>
        Admin - Shipping Rates - <?php echo e(config('app.name')); ?>

    <?php $__env->endSlot(); ?>


    <?php
    $BackUrl = CustomHelper::BackUrl();

    $shippingrate_id = (isset($shippingrates['id']))?$shippingrates['id']:0;
    $shipping_zone_id = (isset($shippingrates['shipping_zone_id']))?$shippingrates['shipping_zone_id']:0;
    $min_weight = (isset($shippingrates['min_weight']))?$shippingrates['min_weight']:0;
    $rate = (isset($shippingrates['rate']))?$shippingrates['rate']:0;
    $max_weight = (isset($shippingrates['max_weight']))?$shippingrates['max_weight']:'';
    $per_kg = (isset($shippingrates['per_kg']))?$shippingrates['per_kg']:'';

    $status = (isset($shippingrates['status']))?$shippingrates['status']:1;

    $action_url = url('admin/shippingrates/'.$shippingrate_id);

    $back_url = (request()->has('back_url'))?request()->back_url:'';
    ?> 
    
	<div class="row">
		<div class="col-md-12">
			<div class="titlehead">
				<h1 class="pull-left">Shipping Rates</h1>

			</div>
		</div>
	</div>         
            
    <div class="row">

        <div class="col-md-12">

            <?php if(session('sccMsg')): ?>
            <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('sccMsg')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('errMsg')): ?>
            <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('errMsg')); ?>

            </div>
            <?php endif; ?>



            <?php echo $__env->make('snippets.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('snippets.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if(session('errMsg')): ?>
            <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo e(session('errMsg')); ?>

            </div>
            <?php endif; ?>

			</div>
	</div>         
            
    <div class="row">

        <div class="col-md-12">
            <div class="bgcolor">
                <form method="POST" action="<?php echo e($action_url); ?>" accept-charset="UTF-8" enctype="multipart/form-data" role="form" class=" ">
                    <?php echo e(csrf_field()); ?>

                    
                    <input type="hidden" name="back_url" value="<?php echo e($back_url); ?>">
					 <div class="col-md-2">
                    <div class="form-group<?php echo e($errors->has('shipping_zone_id') ? ' has-error' : ''); ?> ">
                        <label for="shipping_zone_id" class="control-label required">Zone:</label><br>

                        <select name="shipping_zone_id" id="shipping_zone_id" class="form-control">
                            <option value="">Select</option>
                            <?php
                            $shipping_zone_id = old('shipping_zone_id', $shipping_zone_id);
                            foreach($ShippingZones as $SZ){
                                $selected = '';
                                if($SZ->id == $shipping_zone_id){
                                    $selected = 'selected';
                                }
                                ?>
                                <option value="<?php echo e($SZ->id); ?>" <?php echo e($selected); ?>><?php echo e($SZ->name); ?></option>
                                <?php
                            }
                            ?>
                        </select>                    

                        <?php echo $__env->make('snippets.errors_first', ['param' => 'shipping_zone_id'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
					</div>

					<div class="col-md-2">
					<div class="form-group<?php echo e($errors->has('min_weight') ? ' has-error' : ''); ?> ">
					<label for="min_weight" class="control-label">Min Weight:</label><br>

					<input type="text" id="min_weight" class="form-control" name="min_weight" value="<?php echo e(old('min_weight', $min_weight)); ?>" maxlength="255" />

					<?php echo $__env->make('snippets.errors_first', ['param' => 'min_weight'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
					</div>
					<div class="col-md-2">
					<div class="form-group<?php echo e($errors->has('max_weight') ? ' has-error' : ''); ?> ">
					<label for="max_weight" class="control-label">Max Weight:</label><br>

					<input type="text" id="max_weight" class="form-control" name="max_weight" value="<?php echo e(old('max_weight', $max_weight)); ?>" maxlength="255" />

					<?php echo $__env->make('snippets.errors_first', ['param' => 'max_weight'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
					</div>
					<div class="col-md-2">
                    <div class="form-group<?php echo e($errors->has('rate') ? ' has-error' : ''); ?> ">
                        <label for="rate" class="control-label">Rate:</label><br>

                        <input type="text" id="rate" class="form-control" name="rate" value="<?php echo e(old('rate', $rate)); ?>" maxlength="255" />

                        <?php echo $__env->make('snippets.errors_first', ['param' => 'rate'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
					</div>	



                    <?php
                    $sel_status = old('status', $status);
                    ?>

						<div class="col-md-2">
                    <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?> ">

                        <label for="type" class="control-label required">Status:</label><br>
                        <input type="radio" name="status" value="1" <?php echo e(($sel_status == 1)?'checked':''); ?>>&nbsp;Active
                        &nbsp;
                        <input type="radio" name="status" value="0" <?php echo e(($sel_status == 0)?'checked':''); ?>>&nbsp;Inactive

                        <?php echo $__env->make('snippets.errors_first', ['param' => 'status'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
							</div>



                    <input type="hidden" name="shippingrate_id" value="<?php echo e($shippingrate_id); ?>">


                    <button class="btn btn-success"><i class="fa fa-save"></i> Save</button>

                    <?php
                    if($shippingrate_id > 0){
                        ?>
                        <a href="<?php echo e(url('admin/shippingrates')); ?>" class="btn resetbtn btn-primary" title="Cancel">Cancel</a>
                        <?php
                    }
                    ?>


                </form>
				<div class="clearfix"></div>
            </div>
        </div>
    </div>


            
    <div class="row">

        <div class="col-md-12">
            <?php
            if(!empty($shippingrates_list) && count($shippingrates_list) > 0){
                ?>

                <?php echo e($shippingrates_list->appends(request()->query())->links()); ?>


            <div class="table-responsive">

            <table class="table table-striped table-bordered table-hover">
                <tr>
                    <th>Zone</th>
                    <th>Weight</th>
                    <th>Rate</th>

                    <th>Action</th>
                </tr>
                <?php
                
                    foreach($shippingrates_list as $sr){
                        //pr($dt);
                        //$no_of_product = $brand->products()->count();
                        //pr($brand->countProducts());
                        $sr_min_weight = (!empty($sr->min_weight))?$sr->min_weight:'0';

                        $shipping_zone = '';


            if($sr->shipping_zone_id > 0){
                $ShippingZone = $ShippingRatesModel->ShippingZone($sr->shipping_zone_id);
                //pr($ShippingZone);

                $shipping_zone = (isset($ShippingZone->name))?$ShippingZone->name:'';
            }
                        ?>
                        <tr>
                            <td><?php echo e($shipping_zone); ?></td>
                            <?php
                            /*
                            <td>{{$dt->contents}}</td>
                            */
                            ?>
                            <td>
                            <?php
                            echo number_format($sr_min_weight, 0).'-'. number_format($sr->max_weight, 0);
                            ?>
                            </td>
                            <td><?php echo e($sr->rate); ?></td>
                            
                            <td>
                            <a href="<?php echo e(route('admin.shippingrates.index', [$sr->id])); ?>"><i class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" name="delete" value="Delete" class="delete" data-id="<?php echo e($sr->id); ?>"><i class="fas fa-trash-alt" ></i> </a>

                           
                                <form name="delete_shippingrate" method="post" action="<?php echo e(url('admin/shippingrates/delete/'.$sr->id)); ?>" onsubmit="return confirm('Are you sure to delete this record?')" style="display: inline-block;" id="delete-form-<?php echo e($sr->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="POST">
                                </form>

                            </td>
                        </tr>
                        
                        <?php
                    }
                
                ?>
                
            </table>
            </div>
             <?php echo e($shippingrates_list->appends(request()->query())->links()); ?>

           
            <?php
        }
        else{
            ?>
            <div class="alert alert-warning">No records found.</div>
            <?php
        }
            ?>


        </div>

    </div>

<?php echo $__env->renderComponent(); ?>
<script>
    $('.delete').click(function(){
        var id = $(this).attr('data-id');
        $('#delete-form-'+id).submit();
    });
</script>
<header class="header fullwidth"> 
<div class="logo">
<a href="index.php"><img src="images/logo.png" alt="Slumber Jill" border="0" /></a>
</div>

<div class="navicon"><span></span></div>
<div class="topmenu">
	<ul>
		<li><a href="#">Women</a>
			<ul>
				<li>
					<div class="menutitle">Western Wear</div>
					<ul>
					<li><a href="#">T-Shirts &amp; Tops</a></li>
					<li><a href="#">Tunics</a></li>
					<li><a href="#">Dresses &amp; Jumpsuits</a></li>
					<li><a href="#">Shorts &amp; Skirts</a></li>
					<li><a href="#">Trousers &amp; Capris</a></li>
					<li><a href="#">Shrugs</a></li>
					<li><a href="#">Sweaters &amp; Sweatshirts</a></li>
					<li><a href="#">Jackets</a></li>
					</ul>
				</li>
				<li>
					<div class="menutitle">Active Wear</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				
				<li>
					<div class="menutitle">Fusion Wear</div>
					<ul> 
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				 <li>
					<div class="menutitle">Nightwear &amp; Loungewear</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li><a href="#">Men</a>
			<ul>
				<li>
					<div class="menutitle">Western Wear2</div>
					<ul>
					<li><a href="#">T-Shirts &amp; Tops</a></li>
					<li><a href="#">Tunics</a></li>
					<li><a href="#">Dresses &amp; Jumpsuits</a></li>
					<li><a href="#">Shorts &amp; Skirts</a></li>
					<li><a href="#">Trousers &amp; Capris</a></li>
					<li><a href="#">Shrugs</a></li>
					<li><a href="#">Sweaters &amp; Sweatshirts</a></li>
					<li><a href="#">Jackets</a></li>
					</ul>
				</li>
				<li>
					<div class="menutitle">Active Wear2</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				
				<li>
					<div class="menutitle">Fusion Wear</div>
					<ul> 
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				 <li>
					<div class="menutitle">Nightwear &amp; Loungewear</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li><a href="#">Home Furnishing</a>
		<ul>
				<li>
					<div class="menutitle">Western Wear3</div>
					<ul>
					<li><a href="#">T-Shirts &amp; Tops</a></li>
					<li><a href="#">Tunics</a></li>
					<li><a href="#">Dresses &amp; Jumpsuits</a></li>
					<li><a href="#">Shorts &amp; Skirts</a></li>
					<li><a href="#">Trousers &amp; Capris</a></li>
					<li><a href="#">Shrugs</a></li>
					<li><a href="#">Sweaters &amp; Sweatshirts</a></li>
					<li><a href="#">Jackets</a></li>
					</ul>
				</li>
				<li>
					<div class="menutitle">Active Wear</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				
				<li>
					<div class="menutitle">Fusion Wear</div>
					<ul> 
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
				 <li>
					<div class="menutitle">Nightwear &amp; Loungewear</div>
					<ul>
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Tops</a></li>
					<li><a href="#">Camisoles</a></li>
					<li><a href="#">Sports Bras</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Track Pants</a></li>
					<li><a href="#">Track Suits</a></li>
					<li><a href="#">Leggings</a></li>
					<li><a href="#">Joggers</a></li>
					<li><a href="#">Sports Dresses</a></li>
					<li><a href="#">Sweaters & Sweatshirts</a></li>
					</ul>
				</li>
			</ul>
		</li>
	</ul> 
</div>

<div class="topright">	
	<ul>				
		<li><a href="#"><i class="profileicon"></i><span>Profile</span></a></li>
		<li><a href="#"><i class="wishlisticon"></i><span>Wishlist</span></a></li>
		<li><a href="#"><i class="carticon"></i><small>33</small><span>Bag</span></a></li>
	</ul>
</div>
<div class="searchform">
	<form name="callback_form" method="post" class="callback_form" onsubmit="return(validate_callback());">
		<input type="text" name="name" value="" placeholder="Search for products, brands and category" /><button><i class="searchicon"></i></button>
	</form>
</div>
</header>